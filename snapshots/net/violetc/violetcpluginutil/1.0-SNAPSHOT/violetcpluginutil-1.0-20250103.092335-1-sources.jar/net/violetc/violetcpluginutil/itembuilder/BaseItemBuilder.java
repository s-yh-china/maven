package net.violetc.violetcpluginutil.itembuilder;

import org.bukkit.Material;
import org.bukkit.inventory.meta.ItemMeta;

public class BaseItemBuilder extends ItemBuilder<BaseItemBuilder, ItemMeta> {
    public BaseItemBuilder(Material material) {
        super(material);
    }
}
