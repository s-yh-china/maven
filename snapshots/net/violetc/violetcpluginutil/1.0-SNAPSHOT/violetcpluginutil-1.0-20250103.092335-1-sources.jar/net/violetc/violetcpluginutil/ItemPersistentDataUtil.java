package net.violetc.violetcpluginutil;

import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class ItemPersistentDataUtil {

    @Nullable
    public static <T, Z> Z getData(@Nullable ItemStack item, @NotNull NamespacedKey key, @NotNull PersistentDataType<T, Z> type) {
        ItemMeta itemMeta = getItemHolder(item);
        return itemMeta != null ? itemMeta.getPersistentDataContainer().get(key, type) : null;
    }

    @NotNull
    public static <T, Z> Z getDataOrDef(@Nullable ItemStack holder, @NotNull NamespacedKey key, @NotNull PersistentDataType<T, Z> type, Z def) {
        ItemMeta itemMeta = getItemHolder(holder);
        return itemMeta != null ? itemMeta.getPersistentDataContainer().getOrDefault(key, type, def) : def;
    }

    public static int getIntData(@Nullable ItemStack holder, @NotNull NamespacedKey key) {
        return getDataOrDef(holder, key, PersistentDataType.INTEGER, 0);
    }

    public static int subtractAndGetIntData(@Nullable ItemStack holder, @NotNull NamespacedKey key, int subtract) {
        setIntData(holder, key, getIntData(holder, key) - subtract);
        return getIntData(holder, key);
    }

    public static int addAndGetIntData(@Nullable ItemStack holder, @NotNull NamespacedKey key, int add) {
        setIntData(holder, key, getIntData(holder, key) + add);
        return getIntData(holder, key);
    }

    public static boolean getBoolData(@Nullable ItemStack holder, @NotNull NamespacedKey key) {
        return getIntData(holder, key) == 1;
    }

    public static double getDoubleData(@Nullable ItemStack holder, @NotNull NamespacedKey key) {
        return getDataOrDef(holder, key, PersistentDataType.DOUBLE, 0.0);
    }

    @NotNull
    public static String getStringData(@Nullable ItemStack holder, @NotNull NamespacedKey key) {
        return getDataOrDef(holder, key, PersistentDataType.STRING, "");
    }

    public static <T, Z> void setData(@Nullable ItemStack item, @NotNull NamespacedKey key, @NotNull PersistentDataType<T, Z> type, Z value) {
        ItemMeta itemMeta = getItemHolder(item);
        if (itemMeta != null) {
            itemMeta.getPersistentDataContainer().set(key, type, value);
            item.setItemMeta(itemMeta);
        }
    }

    public static void setIntData(@Nullable ItemStack holder, @NotNull NamespacedKey key, int value) {
        setData(holder, key, PersistentDataType.INTEGER, value);
    }

    public static void setBoolData(@Nullable ItemStack holder, @NotNull NamespacedKey key, boolean value) {
        setIntData(holder, key, value ? 1 : 0);
    }

    public static void setDoubleData(@Nullable ItemStack holder, @NotNull NamespacedKey key, double value) {
        setData(holder, key, PersistentDataType.DOUBLE, value);
    }

    public static void setStringData(@Nullable ItemStack holder, @NotNull NamespacedKey key, String value) {
        setData(holder, key, PersistentDataType.STRING, value);
    }

    public static ItemMeta getItemHolder(@Nullable ItemStack item) {
        return item != null ? item.getItemMeta() : null;
    }
}
