package net.violetc.violetcpluginutil;

import org.bukkit.NamespacedKey;
import org.bukkit.persistence.PersistentDataHolder;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class PersistentDataUtil {

    @Nullable
    public static <T, Z> Z getData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key, @NotNull PersistentDataType<T, Z> type) {
        return holder != null ? holder.getPersistentDataContainer().get(key, type) : null;
    }

    @NotNull
    public static <T, Z> Z getDataOrDef(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key, @NotNull PersistentDataType<T, Z> type, Z def) {
        return holder != null ? holder.getPersistentDataContainer().getOrDefault(key, type, def) : def;
    }

    public static int getIntData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key) {
        return getDataOrDef(holder, key, PersistentDataType.INTEGER, 0);
    }

    public static int subtractAndGetIntData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key, int subtract) {
        setIntData(holder, key, getIntData(holder, key) - subtract);
        return getIntData(holder, key);
    }

    public static int addAndGetIntData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key, int add) {
        setIntData(holder, key, getIntData(holder, key) + add);
        return getIntData(holder, key);
    }

    public static boolean getBoolData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key) {
        return getIntData(holder, key) == 1;
    }

    public static double getDoubleData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key) {
        return getDataOrDef(holder, key, PersistentDataType.DOUBLE, 0.0);
    }

    @NotNull
    public static String getStringData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key) {
        return getDataOrDef(holder, key, PersistentDataType.STRING, "");
    }

    public static <T, Z> void setData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key, @NotNull PersistentDataType<T, Z> type, Z value) {
        if (holder != null) {
            holder.getPersistentDataContainer().set(key, type, value);
        }
    }

    public static void setIntData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key, int value) {
        setData(holder, key, PersistentDataType.INTEGER, value);
    }

    public static void setBoolData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key, boolean value) {
        setIntData(holder, key, value ? 1 : 0);
    }

    public static void setDoubleData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key, double value) {
        setData(holder, key, PersistentDataType.DOUBLE, value);
    }

    public static void setStringData(@Nullable PersistentDataHolder holder, @NotNull NamespacedKey key, String value) {
        setData(holder, key, PersistentDataType.STRING, value);
    }
}
