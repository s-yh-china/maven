package net.violetc.violetcpluginutil;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public class SaveLocation {

    private double x;
    private double y;
    private double z;
    private String world;

    private float pitch;
    private float yaw;

    public SaveLocation(@NotNull Location location) {
        this(location.getX(), location.getY(), location.getZ(), Objects.requireNonNull(location.getWorld()).getName(), location.getPitch(), location.getYaw());
    }

    public SaveLocation(double x, double y, double z, String world) {
        this(x, y, z, world, 0, 0);
    }

    public SaveLocation(double x, double y, double z, String world, float pitch, float yaw) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.world = world;
        this.pitch = pitch;
        this.yaw = yaw;
    }

    public Location toLocation() {
        return new Location(Bukkit.getWorld(world), x, y, z, yaw, pitch);
    }

    public SaveBlockLocation toBlockLocation() {
        return new SaveBlockLocation((int) x, (int) y, (int) z, world);
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public double getZ() {
        return z;
    }

    public float getPitch() {
        return pitch;
    }

    public float getYaw() {
        return yaw;
    }

    public String getWorld() {
        return world;
    }

    public void setPitch(float pitch) {
        this.pitch = pitch;
    }

    public void setWorld(String world) {
        this.world = world;
    }

    public void setX(double x) {
        this.x = x;
    }

    public void setY(double y) {
        this.y = y;
    }

    public void setYaw(float yaw) {
        this.yaw = yaw;
    }

    public void setZ(double z) {
        this.z = z;
    }

    public SaveLocation toWorldLoc() {
        return new SaveLocation(x * 8, y, z * 8, "world");
    }

    public SaveLocation toNetherLoc() {
        return new SaveLocation(x / 8, y, z / 8, "world_nether");
    }

    public String toXaeroMapLoc() {
        return String.format("xaero-waypoint:Waypoint:X:%d:%d:%d:0:false:0:Internal-%s-waypoints", (int) x, (int) y, (int) z, getRealWorld());
    }

    public String toVoxelMapLoc() {
        return String.format("[x:%d,y:%d,z:%d,dimension:%s]", (int) x, (int) y, (int) z, getRealWorld());
    }

    public String getRealWorld() {
        return world.equals("world") ? "overworld" : world;
    }

    public boolean isLocSimilar(@NotNull Location location) {
        return location.getWorld() != null && location.getWorld().getName().equals(world) && location.getX() == x && location.getY() == y && location.getZ() == z;
    }

    public boolean isAllSimilar(@NotNull Location location) {
        return isLocSimilar(location) && location.getYaw() == yaw && location.getPitch() == pitch;
    }
}
