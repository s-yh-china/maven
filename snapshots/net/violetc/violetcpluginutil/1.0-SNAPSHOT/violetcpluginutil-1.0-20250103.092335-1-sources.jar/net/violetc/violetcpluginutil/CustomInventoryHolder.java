package net.violetc.violetcpluginutil;

import org.bukkit.Bukkit;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public class CustomInventoryHolder implements InventoryHolder {

    private final UUID uuid;

    public CustomInventoryHolder() {
        this(UUID.randomUUID());
    }

    public CustomInventoryHolder(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getId() {
        return uuid;
    }

    @NotNull
    @Override
    public Inventory getInventory() {
        return Bukkit.createInventory(this, InventoryType.BEACON);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof CustomInventoryHolder that)) return false;

        return uuid.equals(that.uuid);
    }

    @Override
    public int hashCode() {
        return uuid.hashCode();
    }
}
