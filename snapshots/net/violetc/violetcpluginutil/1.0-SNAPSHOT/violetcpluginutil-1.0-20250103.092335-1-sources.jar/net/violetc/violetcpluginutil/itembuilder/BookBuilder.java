package net.violetc.violetcpluginutil.itembuilder;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BookMeta;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class BookBuilder extends ItemBuilder<BookBuilder, BookMeta> {

    private static final Component NEXT_LINE = Component.text("\n");
    private final List<Component> lineCache;

    public BookBuilder() {
        super(Material.WRITTEN_BOOK);
        this.lineCache = new ArrayList<>();
    }

    public BookBuilder addLine(@NotNull Component mes) {
        this.lineCache.add(mes.append(NEXT_LINE));
        return this;
    }

    public BookBuilder addLine(@NotNull String mes) {
        this.lineCache.add(Component.text(mes).append(NEXT_LINE));
        return this;
    }

    public BookBuilder addLines(String @NotNull ... mes) {
        for (String str : mes) {
            this.addLine(str);
        }
        return this;
    }

    public BookBuilder addHoverShowTextLine(@NotNull String mes, @NotNull String showMes) {
        this.lineCache.add(Component.text(mes).hoverEvent(HoverEvent.showText(Component.text(showMes))).append(NEXT_LINE));
        return this;
    }

    public BookBuilder nextPage() {
        if (lineCache.isEmpty()) {
            this.getItemMeta().addPages();
            return this;
        }

        this.getItemMeta().addPages(lineCache.toArray(new Component[0]));

        this.lineCache.clear();
        return this;
    }

    public BookBuilder setAuthor(@NotNull String author) {
        this.getItemMeta().setAuthor(author);
        return this;
    }

    public BookBuilder setGeneration(@NotNull BookMeta.Generation generation) {
        this.getItemMeta().setGeneration(generation);
        return this;
    }

    public BookBuilder setTitle(@NotNull String title) {
        this.getItemMeta().setTitle(title);
        return this;
    }

    @Override
    public ItemStack build() {
        if (!lineCache.isEmpty()) {
            nextPage();
        }
        return super.build();
    }
}
