package net.violetc.violetcpluginutil;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import org.jetbrains.annotations.NotNull;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;

public abstract class JsonConfig<E extends JsonConfig<E>> {

    public JsonConfig() {
        setUp();
    }

    @SuppressWarnings("unchecked")
    public E load(@NotNull File file) {
        try {
            InputStreamReader reader = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8);
            BufferedReader bf = new BufferedReader(reader);

            E config = (E) new Gson().fromJson(bf, this.getClass());

            bf.close();
            reader.close();

            if (config == null) return setUp();
            else return config;
        } catch (IOException e) {
            VioletcPluginUtil.logger.log(Level.WARNING, "config load error", e);
            return setUp();
        }
    }

    public boolean save(@NotNull File file) {
        try {
            String data = new GsonBuilder().setPrettyPrinting().create().toJson(this);
            FileOutputStream fos = new FileOutputStream(file);
            OutputStreamWriter out = new OutputStreamWriter(fos, StandardCharsets.UTF_8);

            out.write(data);
            out.flush();
            out.close();
            return true;
        } catch (IOException e) {
            VioletcPluginUtil.logger.log(Level.WARNING, "config save error", e);
            return false;
        }
    }

    @SuppressWarnings("unchecked")
    public E init(@NotNull File file) {
        if (file.exists()) {
            return load(file);
        } else {
            save(file);
            return (E) this;
        }
    }

    protected abstract E setUp();
}
