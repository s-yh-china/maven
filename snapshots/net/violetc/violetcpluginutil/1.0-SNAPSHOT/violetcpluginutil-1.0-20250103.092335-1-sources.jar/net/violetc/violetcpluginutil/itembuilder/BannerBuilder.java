package net.violetc.violetcpluginutil.itembuilder;

import org.bukkit.Material;
import org.bukkit.block.banner.Pattern;
import org.bukkit.inventory.meta.BannerMeta;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class BannerBuilder extends ItemBuilder<BannerBuilder, BannerMeta> {

    public static final List<Material> BANNER_LIST = List.of(Material.BLACK_BANNER, Material.CYAN_BANNER, Material.BLUE_BANNER, Material.BROWN_BANNER, Material.GRAY_BANNER, Material.GREEN_BANNER, Material.LIGHT_BLUE_BANNER, Material.LIGHT_GRAY_BANNER, Material.LIME_BANNER, Material.MAGENTA_BANNER, Material.ORANGE_BANNER, Material.PINK_BANNER, Material.PURPLE_BANNER, Material.RED_BANNER, Material.WHITE_BANNER, Material.YELLOW_BANNER);

    public BannerBuilder(@NotNull Material material) {
        super(material);
        if (!BANNER_LIST.contains(material)) {
            throw new IllegalArgumentException("Bad Material");
        }
    }

    public BannerBuilder addPattern(@NotNull Pattern pattern) {
        this.getItemMeta().addPattern(pattern);
        return this;
    }
}
