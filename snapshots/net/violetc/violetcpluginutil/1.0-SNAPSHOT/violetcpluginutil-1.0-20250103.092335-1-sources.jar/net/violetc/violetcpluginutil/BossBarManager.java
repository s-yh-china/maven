package net.violetc.violetcpluginutil;

import org.bukkit.Bukkit;
import org.bukkit.boss.BossBar;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BossBarManager implements Listener {

    private static BossBarManager manager;

    public BossBarManager() {
        manager = this;
    }

    private final Map<String, BossBar> bossBars = new HashMap<>();
    private final Map<String, BossBarDisplayMode> bossBarDisplay = new HashMap<>();
    private final Map<String, List<String>> leavePlayers = new HashMap<>();

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        for (String name : bossBars.keySet()) {
            if (bossBarDisplay.get(name) == BossBarDisplayMode.ALL) {
                bossBars.get(name).addPlayer(event.getPlayer());
            } else if (bossBarDisplay.get(name) == BossBarDisplayMode.ONLY_ADD_PLAYER) {
                if (leavePlayers.getOrDefault(name, List.of()).contains(event.getPlayer().getName())) {
                    leavePlayers.remove(event.getPlayer().getName());
                    bossBars.get(name).addPlayer(event.getPlayer());
                }
            }
        }
    }

    @EventHandler
    public void onPlayerLeave(PlayerQuitEvent event) {
        for (String name : bossBars.keySet()) {
            if (bossBarDisplay.get(name) == BossBarDisplayMode.ONLY_ADD_PLAYER) {
                if (bossBars.get(name).getPlayers().contains(event.getPlayer())) {
                    if (leavePlayers.get(name) == null) {
                        leavePlayers.put(name, new ArrayList<>() {{
                            add(event.getPlayer().getName());
                        }});
                    } else {
                        leavePlayers.get(name).add(event.getPlayer().getName());
                    }
                }
            }
        }
    }

    public static boolean registerBossBar(BossBar bossBar, String name, BossBarDisplayMode displayMode) {
        if (manager.bossBars.containsKey(name)) {
            return false;
        }

        manager.bossBars.put(name, bossBar);
        manager.bossBarDisplay.put(name, displayMode);

        if (displayMode == BossBarDisplayMode.ALL) {
            for (Player player : Bukkit.getOnlinePlayers()) {
                bossBar.addPlayer(player);
            }
        }
        return true;
    }

    public static void unregisterBossBar(BossBar bossBar) {
        String remove = null;
        for (String name : manager.bossBars.keySet()) {
            if (manager.bossBars.get(name) == bossBar) {
                remove = name;
            }
        }
        unregisterBossBar(remove);
    }

    public static void unregisterBossBar(String remove) {
        if (remove != null) {
            BossBar bossBar1 = manager.bossBars.remove(remove);
            manager.bossBarDisplay.remove(remove);
            if (bossBar1 != null) {
                bossBar1.removeAll();
                bossBar1.setVisible(false);
            }
        }
    }

    public static BossBar getBossBar(String name) {
        return manager.bossBars.get(name);
    }

    public enum BossBarDisplayMode {
        ALL, ONLY_ADD_PLAYER
    }
}
