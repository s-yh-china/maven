package net.violetc.violetcpluginutil;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public class SaveBlockLocation {

    private int x;
    private int y;
    private int z;
    private String world;

    public SaveBlockLocation(@NotNull Location location) {
        this(location.getBlockX(), location.getBlockY(), location.getBlockZ(), Objects.requireNonNull(location.getWorld()).getName());
    }

    public SaveBlockLocation(int x, int y, int z, @NotNull String world) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.world = world;
    }

    public Location toLocation() {
        return new Location(Bukkit.getWorld(world), x, y, z);
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getZ() {
        return z;
    }

    public String getWorld() {
        return world;
    }

    public void setWorld(String world) {
        this.world = world;
    }

    public void setX(int x) {
        this.x = x;
    }

    public void setY(int y) {
        this.y = y;
    }

    public void setZ(int z) {
        this.z = z;
    }

    public SaveBlockLocation toWorldLoc() {
        return new SaveBlockLocation(x * 8, y, z * 8, "world");
    }

    public SaveBlockLocation toNetherLoc() {
        return new SaveBlockLocation(x / 8, y, z / 8, "world_nether");
    }

    public String toXaeroMapLoc() {
        return String.format("xaero-waypoint:Waypoint:X:%d:%d:%d:0:false:0:Internal-%s-waypoints", x, y, z, getRealWorld());
    }

    public String toVoxelMapLoc() {
        return String.format("[x:%d,y:%d,z:%d,dimension:%s]", x, y, z, getRealWorld());
    }

    public String getRealWorld() {
        return world.equals("world") ? "overworld" : world;
    }

    public boolean isSimilar(@NotNull Location location) {
        return location.getWorld() != null && location.getWorld().getName().equals(world) && location.getBlockX() == x && location.getBlockY() == y && location.getBlockZ() == z;
    }
}
