package net.violetc.violetcpluginutil;

import org.bukkit.entity.Entity;
import org.jetbrains.annotations.NotNull;

import java.util.Set;

public class TagUtil {

    public static boolean hasTag(@NotNull Entity entity, @NotNull String tag) {
        return entity.getScoreboardTags().contains(tag);
    }

    public static boolean hasTag(@NotNull Entity entity, @NotNull Set<String> tags) {
        for (String tag : tags) {
            if (entity.getScoreboardTags().contains(tag)) {
                return true;
            }
        }
        return false;
    }

    public static void clearTag(@NotNull Entity entity) {
        entity.getScoreboardTags().clear();
    }
}
