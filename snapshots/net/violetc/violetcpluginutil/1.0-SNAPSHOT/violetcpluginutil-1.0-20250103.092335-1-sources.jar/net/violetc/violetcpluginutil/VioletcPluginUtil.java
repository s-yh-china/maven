package net.violetc.violetcpluginutil;

import java.util.logging.Logger;

public final class VioletcPluginUtil extends BaseJavaPlugin {

    public static Logger logger;

    @Override
    public void onEnable() {
        super.onEnable();
        logger = getLogger();

        logger.info("Loading...");
        registerListener(new BossBarManager());
        logger.info("Load success");
    }
}
