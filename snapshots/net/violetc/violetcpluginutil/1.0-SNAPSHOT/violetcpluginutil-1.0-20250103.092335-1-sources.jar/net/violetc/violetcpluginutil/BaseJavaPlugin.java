package net.violetc.violetcpluginutil;

import org.bukkit.Bukkit;
import org.bukkit.command.CommandExecutor;
import org.bukkit.event.HandlerList;
import org.bukkit.event.Listener;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public abstract class BaseJavaPlugin extends JavaPlugin {

    @Override
    public void onEnable() {
        this.getLogger().info("Setup...");
        if (!getDataFolder().exists()) {
            this.getDataFolder().mkdir();
        }
        this.getLogger().info("Setup success");
    }

    @Override
    public void onDisable() {
        this.getLogger().info("Unloading...");
        HandlerList.unregisterAll(this);
        Bukkit.getScheduler().cancelTasks(this);
        this.getLogger().info("Unload success");
    }

    protected void registerListener(@NotNull Listener listener) {
        this.getServer().getPluginManager().registerEvents(listener, this);
    }

    protected void registerCommands(CommandExecutor executor, @NotNull String @NotNull ... cmd) {
        for (String name : cmd) {
            Objects.requireNonNull(getServer().getPluginCommand(name)).setExecutor(executor);
        }
    }
}
