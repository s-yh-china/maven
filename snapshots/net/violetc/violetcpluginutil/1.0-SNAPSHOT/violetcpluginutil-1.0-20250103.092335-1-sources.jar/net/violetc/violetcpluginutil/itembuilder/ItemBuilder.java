package net.violetc.violetcpluginutil.itembuilder;

import net.kyori.adventure.text.Component;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeModifier;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;

public abstract class ItemBuilder<E extends ItemBuilder<E, F>, F extends ItemMeta> {

    private final ItemStack itemStack;
    private final ItemMeta itemMeta;

    public ItemBuilder(@NotNull Material material) {
        this.itemStack = new ItemStack(material);
        this.itemMeta = itemStack.getItemMeta();
    }

    public E addEnchantment(@NotNull Enchantment enchantment, int level) {
        this.itemMeta.addEnchant(enchantment, level, true);
        return getBuilder();
    }

    public E setName(@NotNull String name) {
        return this.setName(Component.text(name));
    }

    public E setName(@NotNull Component name) {
        this.itemMeta.displayName(name);
        return getBuilder();
    }

    public E setLore(int line, @NotNull String lore) {
        return this.setLore(line, Component.text(lore));
    }

    public E setLore(int line, @NotNull Component lore) {
        this.itemMeta.lore(fullList(itemMeta.lore(), line, lore));
        return getBuilder();
    }

    @NotNull
    private List<Component> fullList(@Nullable List<Component> list, int line, Component component) {
        if (list == null) {
            list = new ArrayList<>();
        }

        if (line >= list.size()) {
            for (int i = line - list.size(); i >= 0; i--) {
                list.add(Component.empty());
            }
        }

        list.set(line, component);

        return list;
    }

    public E setUnbreakable(boolean unbreakable) {
        this.itemMeta.setUnbreakable(unbreakable);
        return getBuilder();
    }

    public E setAmount(int amount) {
        this.itemStack.setAmount(amount);
        return getBuilder();
    }

    public E addItemFlags(@NotNull ItemFlag... flags) {
        this.itemMeta.addItemFlags(flags);
        return getBuilder();
    }

    public E addAttributeModifier(@NotNull Attribute attribute, @NotNull AttributeModifier modifier) {
        this.itemMeta.addAttributeModifier(attribute, modifier);
        return getBuilder();
    }

    public <T, Z> E addPersistentData(@NotNull NamespacedKey key, @NotNull PersistentDataType<T, Z> type, @NotNull Z value) {
        this.itemMeta.getPersistentDataContainer().set(key, type, value);
        return getBuilder();
    }

    public E setDamage(short damage) {
        if (itemMeta instanceof Damageable damageable) {
            damageable.setDamage(damage);
        }
        return getBuilder();
    }

    public E setCustomModelData(int customModelData) {
        this.itemMeta.setCustomModelData(customModelData);
        return getBuilder();
    }

    public E setEnchantmentGlintOverride(@Nullable Boolean override) {
        this.itemMeta.setEnchantmentGlintOverride(override);
        return this.getBuilder();
    }

    @SuppressWarnings("unchecked")
    protected F getItemMeta() {
        return (F) this.itemMeta;
    }

    @SuppressWarnings("unchecked")
    protected E getBuilder() {
        return (E) this;
    }

    public ItemStack build() {
        this.itemStack.setItemMeta(itemMeta);
        return itemStack;
    }
}
