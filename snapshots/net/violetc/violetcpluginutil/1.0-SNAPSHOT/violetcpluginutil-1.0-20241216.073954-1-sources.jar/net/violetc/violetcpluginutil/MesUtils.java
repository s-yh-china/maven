package net.violetc.violetcpluginutil;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.concurrent.TimeUnit;

/**
 * 消息与字符串工具集
 */
public class MesUtils {

    /**
     * 将信息发送至所有玩家
     *
     * @param mes 要发送的信息
     */
    public static void sendAllPlayer(@NotNull String... mes) {
        for (Player player : Bukkit.getOnlinePlayers()) {
            player.sendMessage(mes);
        }
    }

    /**
     * 将信息发送至除某个玩家外的所有玩家
     *
     * @param mes    要发送的信息
     * @param player 不接受信息的玩家
     */
    public static void sendOtherPlayer(Player player, String... mes) {
        for (Player player1 : Bukkit.getOnlinePlayers()) {
            if (!player.getName().equals(player1.getName())) {
                player1.sendMessage(mes);
            }
        }
    }

    /**
     * 向玩家发送 action bar 消息
     *
     * @param player 玩家
     * @param mes    要发送的信息
     */
    public static void sendActionBar(@NotNull Player player, @NotNull String mes) {
        player.sendActionBar(Component.text(mes));
    }

    /**
     * 将毫秒转换为小时,分钟,秒的字符串
     *
     * @param milliseconds 要转换的毫秒
     * @return 转换过的字符串
     */
    @NotNull
    public static String millisToHrMinSec(long milliseconds) {
        return millisToHrMinSec(milliseconds, "%d小时%d分钟%d秒");
    }

    /**
     * 将毫秒转换为小时,分钟,秒的字符串
     *
     * @param milliseconds 要转换的毫秒
     * @param format       具体的格式 应该包括四个%d
     * @return 转换过的字符串
     */
    @NotNull
    public static String millisToHrMinSec(long milliseconds, String format) {

        final long hours = TimeUnit.MILLISECONDS.toHours(milliseconds)
                - TimeUnit.DAYS.toHours(TimeUnit.MILLISECONDS.toDays(milliseconds));
        final long minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds)
                - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(milliseconds));
        final long seconds = TimeUnit.MILLISECONDS.toSeconds(milliseconds)
                - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(milliseconds));

        return String.format(format, hours, minutes, seconds);
    }

    /**
     * 将毫秒转换为分钟,秒的字符串
     *
     * @param milliseconds 要转换的毫秒
     * @param format       具体的格式 应该包括四个%d
     * @return 转换过的字符串
     */
    @NotNull
    public static String millisToMinSec(long milliseconds, String format) {

        final long minutes = TimeUnit.MILLISECONDS.toMinutes(milliseconds)
                - TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(milliseconds));
        final long seconds = TimeUnit.MILLISECONDS.toSeconds(milliseconds)
                - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(milliseconds));

        return String.format(format, minutes, seconds);
    }

    @NotNull
    public static String toVoxelMapLoc(@NotNull Location location) {
        return String.format("[x:%d,y:%d,z:%d]", location.getBlockX(), location.getBlockY(), location.getBlockZ());
    }

    @NotNull
    public static String toXaeroMapLoc(@NotNull Location location) {
        return String.format("xaero-waypoint:Waypoint:X:%d:%d:%d:0:false:0", location.getBlockX(), location.getBlockY(), location.getBlockZ());
    }
}
