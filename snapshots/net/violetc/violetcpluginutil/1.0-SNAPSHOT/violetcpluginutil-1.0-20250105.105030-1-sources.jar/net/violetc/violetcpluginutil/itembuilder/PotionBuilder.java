package net.violetc.violetcpluginutil.itembuilder;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.inventory.meta.PotionMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionType;
import org.jetbrains.annotations.NotNull;

import java.util.List;

public class PotionBuilder extends ItemBuilder<PotionBuilder, PotionMeta> {

    public static final List<Material> POTION_LIST = List.of(Material.TIPPED_ARROW, Material.SPLASH_POTION, Material.LINGERING_POTION, Material.POTION);

    public PotionBuilder(Material material) {
        super(material);
        if (!POTION_LIST.contains(material)) {
            throw new IllegalArgumentException("Bad Material");
        }
    }

    public PotionBuilder addCustomEffect(@NotNull PotionEffect effect, boolean overwrite) {
        this.getItemMeta().addCustomEffect(effect, overwrite);
        return this;
    }

    public PotionBuilder setBasePotionType(@NotNull PotionType type) {
        this.getItemMeta().setBasePotionType(type);
        return this;
    }

    public PotionBuilder setColor(@NotNull Color color) {
        this.getItemMeta().setColor(color);
        return this;
    }
}
